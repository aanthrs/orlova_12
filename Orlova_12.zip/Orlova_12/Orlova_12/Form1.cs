﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Orlova_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 10 || textBox1.Text.Length != 40)
            {
                MessageBox.Show("Введите больше 10 символов!", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                textBox1.Focus();

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length < 10 || textBox2.Text.Length != 60)
            {
                MessageBox.Show("Ошибка!", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                textBox1.Focus();

            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length < 10 || textBox2.Text.Length != 60)
            {
                MessageBox.Show("Ошибка!", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                textBox1.Focus();

            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text.Substring(0, 1) == "-")
            {
                var Message = MessageBox.Show("Ввод поля положительных чисел!", "Ошибка!");
                if (Message == DialogResult.OK)
                    textBox4.Text = textBox4.Text.Substring(1);
            }
        }
    }
}
